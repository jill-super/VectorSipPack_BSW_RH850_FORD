package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Indicates model inconsistencies.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelInconsistencyException extends ModelException {

    /**
     * <code>serialVersionUID</code> describes.
     */
    private static final long serialVersionUID = -4784335672833409664L;

    @PublishedMethod
    public ModelInconsistencyException(String message) {
        super(message);
    }

    @PublishedMethod
    public ModelInconsistencyException(String message, Throwable ex) {
        super(message, ex);
    }

}
